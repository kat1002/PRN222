﻿using System.Net.Sockets;
using System.Net;
using System.Text.Json;
using System.Text;
using ServerAppLib;

internal class Program
{
    private static void Main(string[] args)
    {
        ServerAppLib.ServerApp.MainProcess();
    }

    
}

