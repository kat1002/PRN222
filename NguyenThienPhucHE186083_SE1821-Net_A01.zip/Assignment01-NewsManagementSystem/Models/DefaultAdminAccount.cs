﻿namespace Assignment01_NewsManagementSystem.Models
{
    public class DefaultAdminAccount
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
